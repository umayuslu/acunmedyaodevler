﻿using System;

interface IRoute
{
    void fast();
    void fly();
    void floatOnWater(); 
}

class BMW : IRoute
{
    public void fast()
    {
        Console.WriteLine("BMW hızlı gider.");
    }
    public void fly()
    {
        Console.WriteLine("BMW uçar.");
    }
    public void floatOnWater()
    {
        Console.WriteLine("BMW suda yüzebilir.");
    }

    public void DisplayFeatures()
    {
        Console.WriteLine("\nBMW ÖZELLİKLERİ:");
        fast();
        fly();
        floatOnWater();
    }
}

class Porsche : IRoute
{
    public void fast()
    {
        Console.WriteLine("Porsche hızlı gidemez.");
    }
    public void fly()
    {
        Console.WriteLine("Porsche uçabilir.");
    }
    public void floatOnWater()
    {
        Console.WriteLine("Porsche suda yüzebilir.");
    }

    public void DisplayFeatures()
    {
        Console.WriteLine("\nPORSCHE ÖZELLİKLERİ:");
        fast();
        fly();
        floatOnWater();
    }
}

class Mercedes : IRoute
{
    public void fast()
    {
        Console.WriteLine("Mercedes hızlı gidemez.");
    }
    public void fly()
    {
        Console.WriteLine("Mercedes uçamaz.");
    }
    public void floatOnWater()
    {
        Console.WriteLine("Mercedes suda yüzebilir.");
    }

    public void DisplayFeatures()
    {
        Console.WriteLine("\nMERCEDES ÖZELLİKLERİ:");
        fast();
        fly();
        floatOnWater();
    }
}

class Program
{
    static void Main()
    {
        BMW bmw = new BMW();
        Porsche porsche = new Porsche();
        Mercedes mercedes = new Mercedes();

        bmw.DisplayFeatures();
        porsche.DisplayFeatures();
        mercedes.DisplayFeatures();
    }
}
