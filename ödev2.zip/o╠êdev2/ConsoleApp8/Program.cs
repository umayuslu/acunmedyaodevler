﻿using System;

interface IRoute
{
    void salary();

}

class GENELMUDUR : employeer
{
    public override void salary()
    {
        Console.WriteLine("Genel Müdür   ->  80.000");
    }
}

class MUDUR : employeer
{
    public override void salary()
    {
        Console.WriteLine("MUDUR   ->   70.0 L");
    }
}

class PROGRAMCI : employeer
{
    public override void salary()
    {
        Console.WriteLine("PROGRAMCI    ->   60.0 L");
    }
}

class STAJYER : employeer
{
    public override void salary()
    {
        Console.WriteLine("Stajyer             ->  5.000");
    }
}

class Program
{
    static void Main(string[] args)
    {
        GENELMUDUR genelmudur = new GENELMUDUR();
        MUDUR mudur = new MUDUR();
        PROGRAMCI programci = new PROGRAMCI();
        STAJYER stajyer = new STAJYER();

        genelmudur.salary();   
        mudur.salary();
        programci.salary();
        stajyer.salary();

    }
}
