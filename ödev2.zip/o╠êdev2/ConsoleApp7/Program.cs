﻿using System;

abstract class Car
{
    public abstract void Consumption(); 

    public void Sleep()
    {
        Console.WriteLine("Zzz");
    }
}

class BMW : Car
{
    public override void Consumption()
    {
        Console.WriteLine("BMW        ->   80.0 L");
    }
}

class Mercedes : Car
{
    public override void Consumption()
    {
        Console.WriteLine("Mercedes   ->   70.0 L");
    }
}

class Porsche : Car
{
    public override void Consumption()
    {
        Console.WriteLine("Porsche    ->   60.0 L");
    }
}

class Program
{
    static void Main(string[] args)
    {
        BMW bmw = new BMW();
        Mercedes mercedes = new Mercedes();
        Porsche porsche = new Porsche();

        bmw.Consumption();   
        mercedes.Consumption();
        porsche.Consumption();
    }
}
